Hi.
This is a free script and you can use it anywhere.

If you find this script useful do share this with your friends.
---------------------------------------------------------------
website: http://www.thesoftwareguy.in
facebook: https://www.facebook.com/Thesoftwareguy7
twitter: https://www.twitter.com/thesoftwareguy7
google plus: https://www.plus.google.com/+ThesoftwareguyIn


Also you can give us ratings here
---------------------------------
https://www.facebook.com/Thesoftwareguy7/reviews